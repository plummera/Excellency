/*! Excellency - v0.1 - 2016-05-05
 * https://www.github.com/plummera/Excellency//
* Copyright (c) 2016 Anthony T. Plummer; Unlicensed for the free! */
;
